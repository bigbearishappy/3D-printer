#ifndef CONFIG_STORE_H
#define CONFIG_STORE_H

//#include "Configuration.h"

//void Config_ResetDefault(void);

//void Config_PrintSettings(void);

//void Config_StoreSettings(void);
void Config_RetrieveSettings(void);

#endif//CONFIG_STORE_H
