//����ļ������漰������Ҫ�����Ƕ�flash�Ĳ���������ʾ������̨������
#include "Marlin.h"
#include "planner.h"
#include "temperature.h"
#include "ultralcd.h"
#include "ConfigurationStore.h"

/*******************************************************************************************
name:		_EEPROM_writeData()
function:	write data to EEPROM
			[in]	-	&pos:the data address
						*value:the data need to be writen
						size:the room to store the data
			[out]	-	void
*******************************************************************************************/
void _EEPROM_writeData(int &pos, uint8_t* value, uint8_t size)
{

}
#define EEPROM_WRITE_VAR(pos, value) _EEPROM_writeData(pos, (uint8_t*)&value, sizeof(value))
/*******************************************************************************************
name:		_EEPROM_readData()
function:	read data from EEPROM
			[in]	-	&pos:data address
						*value:the value to store the data from eeprom
						size:eeprom's size needed to be read
			[out]	-	void
*******************************************************************************************/
void _EEPROM_readData(int &pos, uint8_t* value, uint8_t size)
{

}
#define EEPROM_READ_VAR(pos, value) _EEPROM_readData(pos, (uint8_t*)&value, sizeof(value))

#define EEPROM_OFFSET 100
#define EEPROM_VERSION "V09"

#ifdef EEPROM_SETTINGS
void Config_StoreSettings() 
{
}

#ifdef EEPROM_SETTINGS
void Config_RetrieveSettings()
{
}

/****************************************************************************************************
name:		Config_ResetDefault()
function:	set all the data to default
			[in]	-	void
			[out]	-	void
****************************************************************************************************/
void Config_ResetDefault()
{
}
