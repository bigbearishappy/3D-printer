#include "Marlin.h"
#include "stepper.h"
#include "planner.h"
#include "temperature.h"
#include "ultralcd.h"
#include "language.h"
#include "cardreader.h"
#include "speed_lookuptable.h"
#if defined(DIGIPOTSS_PIN) && DIGIPOTSS_PIN > -1
#include <SPI.h>
#endif

block_t *current_block;  // A pointer to the block currently being traced

// Variables used by The Stepper Driver Interrupt
static unsigned char out_bits;        // The next stepping-bits to be output
static long counter_x,       // Counter variables for the bresenham line tracer
            counter_y,
            counter_z,
            counter_e;

volatile static unsigned long step_events_completed; // The number of step events executed in the current block

static long acceleration_time, deceleration_time;//����ʱ�䣬����ʱ��
static unsigned short acc_step_rate; // needed for deccelaration start point
static char step_loops;
static unsigned short OCR1A_nominal;
static unsigned short step_loops_nominal;

volatile long endstops_trigsteps[3]={0,0,0};
volatile long endstops_stepsTotal,endstops_stepsDone;
static volatile bool endstop_x_hit=false;
static volatile bool endstop_y_hit=false;
static volatile bool endstop_z_hit=false;

static bool old_x_min_endstop=false;
static bool old_x_max_endstop=false;
static bool old_y_min_endstop=false;
static bool old_y_max_endstop=false;
static bool old_z_min_endstop=false;
static bool old_z_max_endstop=false;

static bool check_endstops = true;

volatile long count_position[NUM_AXIS] = { 0, 0, 0, 0};
volatile signed char count_direction[NUM_AXIS] = { 1, 1, 1, 1};

#define CHECK_ENDSTOPS  if(check_endstops)//�궨���ж���λ����

#define ENABLE_STEPPER_DRIVER_INTERRUPT()  TIMSK1 |= (1<<OCIE1A)//���ز�������ж�
#define DISABLE_STEPPER_DRIVER_INTERRUPT() TIMSK1 &= ~(1<<OCIE1A)

/****************************************************************************************************
name:		checkHitEndstops()
function:	check if the endstops is hit
			[in]	-	void
			[out]	-	void
****************************************************************************************************/
void checkHitEndstops()
{
 if( endstop_x_hit || endstop_y_hit || endstop_z_hit) {
	 printf("%s\r\n",MSG_ENDSTOPS_HIT);
   if(endstop_x_hit) {
	   printf(" X: %.1lf\r\n", (float)endstops_trigsteps[X_AXIS]/axis_steps_per_unit[X_AXIS]);
   }
   if(endstop_y_hit) {
	   printf(" Y: %.1lf\r\n", (float)endstops_trigsteps[Y_AXIS]/axis_steps_per_unit[Y_AXIS]);
   }
   if(endstop_z_hit) {
	   printf(" Z: %.1lf\r\n", (float)endstops_trigsteps[Z_AXIS]/axis_steps_per_unit[Z_AXIS]);
   }
   endstop_x_hit=false;
   endstop_y_hit=false;
   endstop_z_hit=false;	
 }
}

/*****************************************************************************************************
name:		endstops_hit_on_purpose()
function:	make the endstops unable to be hit
			[in]	-	void
			[out]	-	void
*****************************************************************************************************/
void endstops_hit_on_purpose()
{
  endstop_x_hit=false;
  endstop_y_hit=false;
  endstop_z_hit=false;
}

/*************************************************************************************************************
name:		enable_endstops()
function:	make the endstops can be checked when it's hit
			[in]	-	void
			[out]	-	void
*************************************************************************************************************/
void enable_endstops(bool check)
{
  check_endstops = check;
}

/***************************************************************************************************
name:		st_wake_up()
function:	wake up the stepper
			[in]	-	void
			[out]	-	void
***************************************************************************************************/
void st_wake_up() {
  //  TCNT1 = 0;
  ENABLE_STEPPER_DRIVER_INTERRUPT();
}

/***************************************************************************************************
name:		step_wait()
function:	wait for a little while
			[in]	-	void
			[out]	-	void
***************************************************************************************************/
void step_wait(){
    for(int8_t i=0; i < 6; i++){
    }
}

/***********************************************************************************************
name:		calc_timer()
function:	calculate the timer value according to the step rate
			[in]	-	step_rate:stepper's rate
			[out]	-	timer value
***********************************************************************************************/
unsigned short calc_timer(unsigned short step_rate)
{
	unsigned short timer;
	if(step_rate > MAX_STEP_FREQUENCY) step_rate = MAX_STEP_FREQUENCY;

if(step_rate > 20000) { // If steprate > 20kHz >> step 4 times				//������˼
    step_rate = (step_rate >> 2)&0x3fff;
    step_loops = 4;
  }
  else if(step_rate > 10000) { // If steprate > 10kHz >> step 2 times
    step_rate = (step_rate >> 1)&0x7fff;
    step_loops = 2;
  }
  else {
    step_loops = 1;
  }

  if(step_rate < (F_CPU/500000)) step_rate = (F_CPU/500000);				//������˼
  step_rate -= (F_CPU/500000); // Correct for minimal speed
  if(step_rate >= (8*256)){ // higher step rate
    unsigned short table_address = (unsigned short)&speed_lookuptable_fast[(unsigned char)(step_rate>>8)][0];
    unsigned char tmp_step_rate = (step_rate & 0x00ff);
    unsigned short gain = (unsigned short)pgm_read_word_near(table_address+2);
    MultiU16X8toH16(timer, tmp_step_rate, gain);
    timer = (unsigned short)pgm_read_word_near(table_address) - timer;
  }
  else { // lower step rates
    unsigned short table_address = (unsigned short)&speed_lookuptable_slow[0][0];
    table_address += ((step_rate)>>1) & 0xfffc;
    timer = (unsigned short)pgm_read_word_near(table_address);
    timer -= (((unsigned short)pgm_read_word_near(table_address+2) * (unsigned char)(step_rate & 0x0007))>>3);
  }
  if(timer < 100) { timer = 100; MYSERIAL.print(MSG_STEPPER_TOO_HIGH); MYSERIAL.println(step_rate); }//(20kHz this should never happen)
  return timer;
}

// Initializes the trapezoid generator from the current block. Called whenever a new
// block begins.
/****************************************************************************************************
name:		trapezoid_generator_reset()
function:	initialize the trapezoid generator
			[in]	-	void
			[out]	-	void
****************************************************************************************************/
FORCE_INLINE void trapezoid_generator_reset() 
{
  deceleration_time = 0;
  // step_rate to timer interval
  OCR1A_nominal = calc_timer(current_block->nominal_rate);
  // make a note of the number of step loops required at nominal speed
  step_loops_nominal = step_loops;
  acc_step_rate = current_block->initial_rate;
  acceleration_time = calc_timer(acc_step_rate);
  OCR1A = acceleration_time;
}

// "The Stepper Driver Interrupt" - This timer interrupt is the workhorse.
// It pops blocks from the block_buffer and executes them by pulsing the stepper pins appropriately.
/****************************************************************************************************
name:		ISR
function:	�����ʱ���ж�����Ҫ����������������ƿ��������Ȼ��������λ�����Լ���������ľ����ƶ�
****************************************************************************************************/
ISR(TIMER1_COMPA_vect)
{}

/***************************************************************************************************
name:		st_init()
function:	initialize the stepper
			[in]	-	void
			[out]	-	void
***************************************************************************************************/
void st_init()
{
  digipot_init(); //Initialize Digipot Motor Current
  microstep_init(); //Initialize Microstepping Pins

#ifdef X_DIR_PIN && X_DIR_PIN > -1								//DIR
	//��������Ϊ���
#endif
#ifdef Y_DIR_PIN && Y_DIR_PIN > -1
	//��������Ϊ���
#endif
#ifdef Z_DIR_PIN && Z_DIR_PIN > -1
	//��������Ϊ���
#endif
#if defined(E0_DIR_PIN) && E0_DIR_PIN > -1
    //��������Ϊ���
#endif

#ifdef X_ENABLE_PIN && X_ENABLE_PIN > -1						//EN
	//��������Ϊ���
#endif
#ifdef Y_ENABLE_PIN && Y_ENABLE_PIN > -1
	//��������Ϊ���
#endif
#ifdef Z_ENABLE_PIN && Z_ENABLE_PIN > -1
	//��������Ϊ���
#endif
#ifdef E0_ENABLE_PIN && E0_ENABLE_PIN > -1
	//��������Ϊ���
#endif

#ifdef X_MIN_PIN && X_MIN_PIN > -1								//ENDSTOP
	//��������Ϊ����
#endif
#ifdef Y_MIN_PIN && Y_MIN_PIN > -1
	//��������Ϊ����
#endif
#ifdef Z_MIN_PIN && Z_MIN_PIN > -1
	//��������Ϊ����
#endif
#ifdef X_MAX_PIN && X_MIN_PIN > -1
	//��������Ϊ����
#endif
#ifdef Y_MAX_PIN && Y_MIN_PIN > -1
	//��������Ϊ����
#endif
#ifdef Z_MAX_PIN && Z_MIN_PIN > -1
	//��������Ϊ����
#endif

#if defined(X_STEP_PIN) && (X_STEP_PIN > -1)					//STEP
    //��������Ϊ���
    //����io��ֵдΪ��
    disable_x();
#endif
#if defined(Y_STEP_PIN) && (Y_STEP_PIN > -1)					
    //��������Ϊ���
    //����io��ֵдΪ��
    disable_x();
#endif
#if defined(Z_STEP_PIN) && (Z_STEP_PIN > -1)					
    //��������Ϊ���
    //����io��ֵдΪ��
    disable_x();
#endif
#if defined(E0_STEP_PIN) && (E0_STEP_PIN > -1)					
    //��������Ϊ���
    //����io��ֵдΪ��
    disable_x();
#endif

  // waveform generation = 0100 = CTC							//���η���
  //TCCR1B &= ~(1<<WGM13);
  //TCCR1B |=  (1<<WGM12);
  //TCCR1A &= ~(1<<WGM11);
  //TCCR1A &= ~(1<<WGM10);

  // output mode = 00 (disconnected)
  //TCCR1A &= ~(3<<COM1A0);
  //TCCR1A &= ~(3<<COM1B0);

ENABLE_STEPPER_DRIVER_INTERRUPT();

  enable_endstops(true); // Start with endstops active. After homing they can be disabled
  sei();
}

// Block until all buffered steps are executed
/****************************************************************************************************
name:		st_synchronize()
function:	check the block queue and executed it
			[in]	-	void
			[out]	-	void
***************************************************************************************************/
void st_synchronize()
{
    while( blocks_queued()) {
    manage_heater();
    manage_inactivity();
    lcd_update();
  }
}

/**************************************************************************************************
name:		st_set_position()
function:	set the position of the extruder
			[in]	-	&x:x axis value
						&y:y axis value
						&z:z axis value
						&e:extruder value
**************************************************************************************************/
void st_set_position(const long &x, const long &y, const long &z, const long &e)
{
  CRITICAL_SECTION_START;
  count_position[X_AXIS] = x;
  count_position[Y_AXIS] = y;
  count_position[Z_AXIS] = z;
  count_position[E_AXIS] = e;
  CRITICAL_SECTION_END;
}

/**************************************************************************************************
name:		st_set_e_position()
function:	set the position of the extruder
			[in]	-	&e:extruder value
**************************************************************************************************/
void st_set_e_position(const long &e)
{
  CRITICAL_SECTION_START;
  count_position[E_AXIS] = e;
  CRITICAL_SECTION_END;
}

/*************************************************************************************************
name:		st_get_position()
function:	get a axis's count
			[in]	-	axis:a axis
			[out]	-	long:the value
*************************************************************************************************/
long st_get_position(uint8_t axis)
{
  long count_pos;
  CRITICAL_SECTION_START;
  count_pos = count_position[axis];
  CRITICAL_SECTION_END;
  return count_pos;
}

/***************************************************************************************************
name:		finishAndDisableSteppers()
function:	check the command and disable all the steppers
			[in]	-	void
			[out]	-	void
***************************************************************************************************/
void finishAndDisableSteppers()
{
  st_synchronize();
  disable_x();
  disable_y();
  disable_z();
  disable_e0();
  disable_e1();
  disable_e2();
}

/**************************************************************************************************
name:		quickStop()
function:	stop the printer
			[in]	-	void
			[out]	-	void
**************************************************************************************************/
void quickStop()
{
  DISABLE_STEPPER_DRIVER_INTERRUPT();
  while(blocks_queued())
    plan_discard_current_block();
  current_block = NULL;
  ENABLE_STEPPER_DRIVER_INTERRUPT();
}