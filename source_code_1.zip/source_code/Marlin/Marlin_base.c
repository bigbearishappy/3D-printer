#include"Marlin.h"

/*void get_command();					//�õ�����ĺ�������
void process_commands();			//��������ĺ�������
void manage_inactivity();			//�����޶����Ĳ���
void FlushSerialRequestResend();	//���´�����Ҫ���·�������
void ClearToSend();					//�����������
void get_coordinates();

void prepare_move();				//׼���ƶ�
void kill();
void Stop();

bool IsStopped();					//�ж��Ƿ�ֹͣ

void enquecommand(const char *cmd); //put an ascii command at the end of the current buffer.
void enquecommand_P(const char *cmd); //put an ascii command at the end of the current buffer, read from flash
void prepare_arc_move(char isclockwise);
void clamp_to_software_endstops(float target[3]);
*/

/****************************************************************************
name:		system_init()
function:	
			[in]	-	void
			[out]	-	void
****************************************************************************/
void system_init()
{
	setup_killpin();
	setup_powerhold();
	printf("%d\n",BAUDRATE);
	printf("start\n");

//�����кܶ࿪��ʱ�Ĵ�ӡ��Ϣ�������Ժ�ר������20160412

  // loads data from EEPROM if available else uses defaults (and resets step acceleration rate)
  Config_RetrieveSettings();

  tp_init();				// Initialize temperature loop
  plan_init();				// Initialize planner;
  watchdog_init();
  st_init();				// Initialize stepper, this enables interrupts!
  setup_photpin();
  servo_init();
  delay(1000)
}

/****************************************************************************
name:		setup_killpin()
function:	configuration of the kill pin
			[in]	-	void
			[out]	-	void
****************************************************************************/
void setup_killpin()
{
	//judge if the kill pin is defined
	//if so, make the kill pin to be int the output mode
	//write the high
}

/****************************************************************************
name:		setup_powerhold()
function:	make the power supply work properly
			[in]	-	void
			[out]	-	void
****************************************************************************/
void setup_powerhold()
{
	//judge if the suicide pin is defined
}

/////////////////////////////////////////////////////////////////////////
/****************************************************************************
name:		enquecommand()
function:	add a command to the command buffer
			[in]	-	*cmd:the pointer of the command which will be added
						to the command buffer
			[out]	-	void
****************************************************************************/
void enquecommand(const char *cmd)
{
	if(buflen < BUFSIZE)
	{
		strcpy();
		buflen += 1;
	}
}

/****************************************************************************
name:		setup_killpin()
function:	configuration of the kill pin
			[in]	-	void
			[out]	-	void
****************************************************************************/
void setup_killpin()
{
	//judge if the kill pin is defined
	//if so, make the kill pin to be int the output mode
	//write the high
}

/****************************************************************************
name:		setup_photopin()
function:	configuration of the photo pin
			[in]	-	void
			[out]	-	void
****************************************************************************/
void setup_photopin()
{
	//judge if the photo is defined
	//if so, make the photo pin to be in the output mode
	//write the low
}

/****************************************************************************
name:		setup_powerhold()
function:	make the power supply work properly
			[in]	-	void
			[out]	-	void
****************************************************************************/
void setup_powerhold()
{
	//judge if the suicide pin is defined
}

/****************************************************************************
name:		suicide()
function:	stop the printer
			[in]	-	void
			[out]	-	void
****************************************************************************/
void suicide()
{
	//make the suicide pin output the low
}

/****************************************************************************
name:		system_init()
function:	
			[in]	-	void
			[out]	-	void
****************************************************************************/
void system_init()
{
	setup_killpin();
	setup_powerhold();
	printf("%d\n",BAUDRATE);
	printf("start\n");

  // loads data from EEPROM if available else uses defaults (and resets step acceleration rate)
  Config_RetrieveSettings();

  tp_init();				// Initialize temperature loop
  plan_init();				// Initialize planner;
  watchdog_init();
  st_init();				// Initialize stepper, this enables interrupts!
  setup_photpin();
  servo_init();
  delay(1000)
}

/****************************************************************************
name:		get_command()
function:	get the command from the cmd buffer
			[in]	-	void
			[out]	-	void
****************************************************************************/
void get_command()
{
	while(/*serial data is available and the buflen is less than BUFSIZE*/)
	{
		//get the data
		if(serial_char == '\n' || serial_char == '\r' ||
		(serial_char == ':' && comment_mode == false) ||
		serial_count >= (MAX_CMD_SIZE - 1))
		{
			if(serial_count){						//if empty line
				comment_mode = false;				//for new line
				return;
			}
			cmdbuffer[bufindw][serial_count] = 0;	//terminate string
			if(!comment_mode){
				comment_mode = false;				//for new command
				fromsd[bufindw] = false;
				if(strchr(cmdbuffer[bufindw], 'N') != NULL){
					strchr_pointer = strchr(cmdbuffer[bufindw], 'N');
					gcode_N = (strtol(&cmdbuffer[bufindw][strchr_pointer - cmdbuffer[bufindw] + 1], NULL, 10));
					
				}					
			}
		}
	}
}

/****************************************************************************
name:		code_value()
function:	transform the string to the float number
			[in]	-	void
			[out]	-	void
****************************************************************************/
float code_value()
{
	return (strtod(&cmdbuffer[bufindw][strchr_pointer - cmdbuffer[bufindr] + 1], NULL));
}

/****************************************************************************
name:		code_value_long()
function:	transform the string to the long number
			[in]	-	void
			[out]	-	void
****************************************************************************/
long code_value_long()
{
	return (strtol(&cmdbuffer[bufindr][strchr_pointer - cmdbuffer[bufindr] + 1], NULL, 10));
}

/****************************************************************************
name:		code_seen()
function:	try to find a code in a string,retrun true if it is found,
			else return false
			[in]	-	code:the code need to be found
			[out]	-	bool:true or false
****************************************************************************/
bool code_seen(char code)
{
	strchr_pointer = strchr(cmdbuffer[bufindr], code);
	return (strchr_pointer != NULL);
}

/****************************************************************************
name:		x_home_pos()
function:	when the extruder is in the home,return it's position
			[in]	-	extruder:the extruder
			[out]	-	float:the extruder's position on the x axis
****************************************************************************/
static float x_home_pos(int extruder)
{
	if(extruder == 0)
		return base_home_pos(X_AXIS) + add_homeing[X_AXIS];
	else
		return (extruder_offset[X_AXIS][1] > 0) ? extruder_offset[X_AXIS][1] : X2_HOME_POS;
}

/****************************************************************************
name:		x_home_dir()
function:	return the direction of the extruder when it go home
			[in]	-	extruder
			[out]	-	int
****************************************************************************/
static int x_home_dir(int extruder)
{
	return (extruder == 0) ? X_HOME_DIR : X2_HOME_DIR;
}

/****************************************************************************
name:		axis_is_at_home()
function:	unknown
			[in]	-	axis
			[out]	-	void
****************************************************************************/
static void axis_is_at_home(int axis)
{
	current_position[axis] =	base_home_pos(axis) + add_homeing[axis];
	min_pos[axis] =				base_min_pos(axis)  + add_homeing[axis];
	max_pos[axis] =				base_max_pos(axis)  + add_homeing[axis];
}

/***************************************************************************************************
name:		do_blocking_move_to()
function:	execute the command block and move to the target position
			[in]	-	x:x axis
						y:y axis
						z:z axis
			[out]	-	void
***************************************************************************************************/
static void do_blocking_move_to(float x, float y, float z)
{
    float oldFeedRate = feedrate;

    feedrate = XY_TRAVEL_SPEED;

    current_position[X_AXIS] = x;
    current_position[Y_AXIS] = y;
    current_position[Z_AXIS] = z;
    plan_buffer_line(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS], feedrate/60, active_extruder);
    st_synchronize();

    feedrate = oldFeedRate;
}

/***************************************************************************************************
name:		do_blocking_move_relative()
function:	correcting the position
			[in]	-	offset_x:x axis's offset
						offset_y:y axis's offset
						offset_z:z axis's offset
			[out]	-	void
***************************************************************************************************/
static void do_blocking_move_relative(float offset_x, float offset_y, float offset_z) {
    do_blocking_move_to(current_position[X_AXIS] + offset_x, current_position[Y_AXIS] + offset_y, current_position[Z_AXIS] + offset_z);
}

/***************************************************************************************************
name:		setup_for_endstop_move()
function:	configuration the printer's data when the endstop is hit
			[in]	-	void
			[out]	-	void
***************************************************************************************************/
static void setup_for_endstop_move() 
{
    saved_feedrate = feedrate;
    saved_feedmultiply = feedmultiply;
    feedmultiply = 100;
    previous_millis_cmd = millis();

    enable_endstops(true);
}

/***************************************************************************************************
name:		clean_up_after_endstop_move()
function:	recover the relative data when the endstop was hit
			[in]	-	void
			[out]	-	void
***************************************************************************************************/
static void clean_up_after_endstop_move() {
#ifdef ENDSTOPS_ONLY_FOR_HOMING
    enable_endstops(false);
#endif

    feedrate = saved_feedrate;
    feedmultiply = saved_feedmultiply;
    previous_millis_cmd = millis();
}

/***************************************************************************************************
name:		homeaxis()
function:	??????????????????
			[in]	-	void
			[out]	-	void
***************************************************************************************************/
static void homeaxis(int axis)
{
}

/***************************************************************************************************
name:		process_commands()
function:	decode the Gcode
			[in]	-	void
			[out]	-	void
***************************************************************************************************/
void process_commands()
{
}

/***************************************************************************************************
name: 	  	FlushSerialRequestResend()
function:   flush the serial port and request to resend the data
			[in]	  -   void
			[out]   -   void
***************************************************************************************************/
void FlushSerialRequestResend()
{
  //char cmdbuffer[bufindr][100]="Resend:";
  MYSERIAL.flush();
  SERIAL_PROTOCOLPGM(MSG_RESEND);
  SERIAL_PROTOCOLLN(gcode_LastN + 1);
  ClearToSend();
}

/***************************************************************************************************
name: 	  	ClearToSend()
function:   send ok
		  	[in]	  -   void
		  	[out]   -   void
***************************************************************************************************/
void ClearToSend()
{
  previous_millis_cmd = millis();
  #ifdef SDSUPPORT
  if(fromsd[bufindr])
    return;
  #endif //SDSUPPORT
  SERIAL_PROTOCOLLNPGM(MSG_OK);
}

/***************************************************************************************************
name:		get_coordinate()
function:	get the coordinate of the extruder
			[in]	-	void
			[out]	-	void
***************************************************************************************************/
void get_coordinates()
{
}

/***************************************************************************************************
name:		get_arc_coordiantes()
function:	get the arc coordinate of the extruder
			[in]	-	void
			[out]	-	void
***************************************************************************************************/
void get_arc_coordinates()//�õ�������
{
#ifdef SF_ARC_FIX
   bool relative_mode_backup = relative_mode;
   relative_mode = true;
#endif
   get_coordinates();
#ifdef SF_ARC_FIX
   relative_mode=relative_mode_backup;
#endif

   if(code_seen('I')) {
     offset[0] = code_value();
   }
   else {
     offset[0] = 0.0;
   }
   if(code_seen('J')) {
     offset[1] = code_value();
   }
   else {
     offset[1] = 0.0;
   }
}

/*****************************************************************************************
name:		clamp_to_software_endstops()
function:	use the software to judge the current position is proper
			[in]	-	target[3]:x,y,z axis endstop
			[out]	-	void
*****************************************************************************************/
void clamp_to_software_endstops(float target[3])
{
  if (min_software_endstops) {
    if (target[X_AXIS] < min_pos[X_AXIS]) target[X_AXIS] = min_pos[X_AXIS];
    if (target[Y_AXIS] < min_pos[Y_AXIS]) target[Y_AXIS] = min_pos[Y_AXIS];
    if (target[Z_AXIS] < min_pos[Z_AXIS]) target[Z_AXIS] = min_pos[Z_AXIS];
  }

  if (max_software_endstops) {
    if (target[X_AXIS] > max_pos[X_AXIS]) target[X_AXIS] = max_pos[X_AXIS];
    if (target[Y_AXIS] > max_pos[Y_AXIS]) target[Y_AXIS] = max_pos[Y_AXIS];
    if (target[Z_AXIS] > max_pos[Z_AXIS]) target[Z_AXIS] = max_pos[Z_AXIS];
  }
}

/*********************************************************************************************
name:		prepare_move()
function:	movement
			[in]	-	void
			[out]	-	void
*********************************************************************************************/
void prepare_move()
{
}

/*********************************************************************************************
name:		prepare_arc_move()
function:	prepare the arc move
			[in]	-	void
			[out]	-	void
*********************************************************************************************/
void prepare_arc_move(char isclockwise) {
  float r = hypot(offset[X_AXIS], offset[Y_AXIS]); // Compute arc radius for mc_arc

  // Trace the arc
  mc_arc(current_position, destination, offset, X_AXIS, Y_AXIS, Z_AXIS, feedrate*feedmultiply/60/100.0, r, isclockwise, active_extruder);

  // As far as the parser is concerned, the position is now == target. In reality the
  // motion control system might still be processing the action and the real tool position
  // in any intermediate location.
  for(int8_t i=0; i < NUM_AXIS; i++) {
    current_position[i] = destination[i];
  }
  previous_millis_cmd = millis();
}

/***************************************************************************************
name:		handle_status_leds()
function:	control the status of leds
			[in]	-	void
			[out]	-	void
***************************************************************************************/
void handle_status_leds(void) {
  float max_temp = 0.0;
  if(millis() > stat_update) {
    stat_update += 500; // Update every 0.5s
    for (int8_t cur_extruder = 0; cur_extruder < EXTRUDERS; ++cur_extruder) {
       max_temp = max(max_temp, degHotend(cur_extruder));
       max_temp = max(max_temp, degTargetHotend(cur_extruder));
    }
    #if defined(TEMP_BED_PIN) && TEMP_BED_PIN > -1
      max_temp = max(max_temp, degTargetBed());
      max_temp = max(max_temp, degBed());
    #endif
    if((max_temp > 55.0) && (red_led == false)) {
      digitalWrite(STAT_LED_RED, 1);
      digitalWrite(STAT_LED_BLUE, 0);
      red_led = true;
      blue_led = false;
    }
    if((max_temp < 54.0) && (blue_led == false)) {
      digitalWrite(STAT_LED_RED, 0);
      digitalWrite(STAT_LED_BLUE, 1);
      red_led = false;
      blue_led = true;
    }
  }
}

/***************************************************************************************
name:		manage_inactivity()
function:	manage the printer when it has nothing to do
			[in]	-	void
			[out]	-	void
***************************************************************************************/
void manage_inactivity()
{
}

/*********************************************************************************************
name:		kill()
function:	disable all the function of the printer
			[in]	-	void
			[out]	-	void
*********************************************************************************************/
void kill()
{
  cli(); // Stop interrupts
  disable_heater();

  disable_x();
  disable_y();
  disable_z();
  disable_e0();
  disable_e1();
  disable_e2();

#if defined(PS_ON_PIN) && PS_ON_PIN > -1
  pinMode(PS_ON_PIN,INPUT);
#endif
  SERIAL_ERROR_START;
  SERIAL_ERRORLNPGM(MSG_ERR_KILLED);
  LCD_ALERTMESSAGEPGM(MSG_KILLED);
  suicide();
  while(1) { /* Intentionally left empty */ } // Wait for reset
}

/***************************************************************************************
name:		Stop()
function:	stop the printer
			[in]	-	void
			[out]	-	void
***************************************************************************************/
void Stop()
{
  disable_heater();
  if(Stopped == false) {
    Stopped = true;
    Stopped_gcode_LastN = gcode_LastN; // Save last g_code for restart
    SERIAL_ERROR_START;
    SERIAL_ERRORLNPGM(MSG_ERR_STOPPED);
    LCD_MESSAGEPGM(MSG_STOPPED);
  }
}

/***************************************************************************************
name:		IsStopped()
function:	check if the printer is stopped
			[in]	-	void
			[out]	-	void
***************************************************************************************/
bool IsStopped() 
{ 
	return Stopped; 
}

/***************************************************************************************
name:		setTargetedHotend()
function:	set the target hotend
			[in]	-	code:the code to chose the hotend
			[out]	-	void
***************************************************************************************/
bool setTargetedHotend(int code){
  tmp_extruder = active_extruder;
  if(code_seen('T')) {
    tmp_extruder = code_value();
    if(tmp_extruder >= EXTRUDERS) {
      SERIAL_ECHO_START;
      switch(code){
        case 104:
          SERIAL_ECHO(MSG_M104_INVALID_EXTRUDER);
          break;
        case 105:
          SERIAL_ECHO(MSG_M105_INVALID_EXTRUDER);
          break;
        case 109:
          SERIAL_ECHO(MSG_M109_INVALID_EXTRUDER);
          break;
        case 218:
          SERIAL_ECHO(MSG_M218_INVALID_EXTRUDER);
          break;
      }
      SERIAL_ECHOLN(tmp_extruder);
      return true;
    }
  }
  return false;
}

