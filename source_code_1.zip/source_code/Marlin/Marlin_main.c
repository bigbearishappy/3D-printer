#include"stm32f10x.h"
#include"Marlin.h"
#include "ConfigurationStore.h"

/****************************************************************************
name:		main()
function:	main
			[in]	-	void
			[out]	-	void
****************************************************************************/
int main()
{
	//system_init();
	/*for(;;)
	{
		if(buflen < (BUFSIZE - 1))
			get_command();
		if(buflen)
		{
			process_command();
			buflen -= 1;
		}
		manage_heater();
		manage_inactivity();
		checkHitEndstops();
	}*/
}
