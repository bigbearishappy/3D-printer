#ifndef temperature_h
#define temperature_h

#include"Marlin.h"
#include"planner.h"
#ifdef PID_ADD_EXTRUSION_RATE
	#include"stepper.h"
#endif

//FUNCTION
void tp_init();
void manage_heater();

int getHeaterPower(int heater);
void disable_heater();
void setWatch();
void updatePID();

void PID_autotune(float temp, int extruder, int ncycles);

static float analog2temp(int raw, uint8_t e);
static float analog2tempBed(int raw);
static void updateTemperaturesFromRawValues();

#ifdef PIDTEMP
	extern float Kp, Ki, Kd, Kc;
	float scalePID_i(float i);		//why there is no scalePID_p()
	float scalePID_d(float);
	float unscalePID_i(float i);
	float unscalePID_d(float);
#endif

//�����кܶ�С�ĺ�������ԭ���Ĵ�������ʹ����ǿ����������������Կ���ʹ�ú궨�庯�����滻
float degHotend(uint8_t extruder)
{
	return current_temperature[extruder];
}

float degBed() 
{
	return current_temperature_bed;
}

float degTargetHotend(uint8_t extruder) 
{  
	return target_temperature[extruder];
}

float degTargetBed() 
{   
	return target_temperature_bed;
}

void setTargetHotend(const float &celsius, uint8_t extruder) 
{  
	target_temperature[extruder] = celsius;
}

void setTargetBed(const float &celsius) 
{  
	target_temperature_bed = celsius;
}

bool isHeatingHotend(uint8_t extruder)
{  
	return target_temperature[extruder] > current_temperature[extruder];
}

bool isHeatingBed() 
{
	return target_temperature_bed > current_temperature_bed;
}

bool isCoolingHotend(uint8_t extruder) 
{  
	return target_temperature[extruder] < current_temperature[extruder];
}

 bool isCoolingBed() 
{
	return target_temperature_bed < current_temperature_bed;
}

void autotempShutdown()
{
#ifdef AUTOTEMP
	if(autotemp_enabled)					//autotemp_enabled is defined in the planner.c
	{
		autotemp_enabled=false;
		if(degTargetHotend(active_extruder)>autotemp_min)
			setTargetHotend(0,active_extruder);
		}
#endif
}

#endif